# Master Prompt PRD: Sistem Manajemen Program NGO, TOR & Cash Advance (Yayasan WIJNA)

Dokumen ini merumuskan **Master Prompt PRD (Product Requirements Document)** komprehensif siap pakai untuk AI Studio. Master Prompt ini menyatukan seluruh akumulasi kebutuhan bisnis, spesifikasi teknis, aturan tata kelola keuangan, dan estetika Notion yang telah dibangun pada sistem.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> **Keputusan yang Dikonfirmasi dari Fase Klarifikasi:**
> - **Cakupan Sistem:** End-to-End menyeluruh dari penyusunan Kerangka Acuan Kerja (TOR), hierarki program organisasi, persetujuan bertingkat, pengajuan Cash Advance operasional multi-tahap, hingga Ringkasan Pertanggungjawaban Dana dan Jejak Audit Terpisah.
> - **Format Prompt:** Master Prompt PRD terstruktur profesional untuk Google AI Studio Build, yang merinci aturan arsitektur data, formula kalkulasi keuangan, validasi formulir, dan panduan desain UI/UX tanpa ada logika yang terpotong.

---

## 1. Overview & Core Concept

Master Prompt ini dirancang untuk menginstruksikan AI membangun sebuah **Sistem Tata Kelola Program & Keuangan Operasional NGO (Non-Governmental Organization)** yang akuntabel, terstruktur, dan elegan.

Sistem melayani alur kerja organisasi pembangunan:
1. **Perencanaan & Program Management:** Hierarki 4-level (`Program → Outcome → Output → Activity`), penyusunan TOR berstandar donor, matriks peserta, rencana mitigasi risiko, dan jadwal rundown.
2. **Alur Persetujuan Bertingkat (Multi-tier Approval):** Mekanisme review role-based (`Staff / PIC → Program Manager → Finance → Director`) dengan validasi hak akses dan jejak riwayat audit persetujuan.
3. **Pengajuan Uang Muka Kegiatan (Cash Advance):** Pengajuan uang muka bertahap (`CA #01`, `CA #02`, dst.) dengan penomoran berjenjang (`CA/001.01`, `CA/001.02`), pemilihan kode budget murni dari Master Budget, dan struktur kalkulasi rincian kebutuhan: `Volume × Frekuensi × Biaya Satuan`.
4. **Ringkasan Akumulasi & Pertanggungjawaban Kasbon:** Konsolidasi otomatis seluruh cash advance yang telah diajukan ke dalam kode budget tunggal (tanpa duplikasi baris), pencatatan realisasi belanja riil, kalkulasi otomatis sisa uang muka atau kekurangan kasbon, dan pencatatan Jejak Audit Terpisah (*Dedicated Audit Trail*).

---

## 2. User Experience & Visual Design (Notion-Inspired Workspace)

### Karakteristik Visual & Desain UI
- **Estetika:** *Notion-inspired*, minimalis, modern, document-centric, dan editorial. Menghindari tampilan SaaS dashboard generik yang serba putih atau penuh dengan kartu besar mengambang.
- **Color Palette:**
  - Latar aplikasi: Warm Light-Gray (`#F5F6F7` / `#FAFAF9`)
  - Permukaan dokumen: White (`#FFFFFF`) dengan border halus (`#EDEDEC` / `#E7E5E4`)
  - Tipografi utama: Dark Charcoal (`#292524` / `#2F3437`)
  - Aksen primer & kode: Muted Navy/Blue (`#1E3A8A` / `#1D4ED8`)
  - Aksen status berhasil: Soft Emerald (`#047857` / `#15803D`)
  - Aksen peringatan / kekurangan: Rose/Amber (`#B91C1C` / `#D97706`)
- **Spacing & Layout:** Spasi kompak (12–16px antar komponen, 20–24px antar seksi besar). Menghindari kartu besar terisolasi; informasi disajikan dalam nested hierarchy bergaris tipis.
- **Tipografi:** Font sans-serif modern (Inter / System Sans), judul dokumen terukur (21–24px), subjudul seksi (14–16px), teks isi (13–14px), metadata & kode mono (10.5–12px).

---

## 3. Arsitektur Teknis & Komponen Sistem

```
┌────────────────────────────────────────────────────────────────────────┐
│                        YAYASAN WIJNA WORKSPACE                         │
├───────────────────────────────────┬────────────────────────────────────┤
│ 1. PROGRAM & TOR MANAGEMENT       │ 2. CASH ADVANCE & FINANCE          │
│ ┌───────────────────────────────┐ │ ┌────────────────────────────────┐ │
│ │ Hierarki 4-Level Program     │ │ │ Formulir Cash Advance (Modal)  │ │
│ │ • Program Induk               │ │ │ • No: CA/001.01, CA/001.02     │ │
│ │ • Outcome                     │ │ │ • Dropdown Kode Budget Murni   │ │
│ │ • Output                      │ │ │ • Volume | Satuan | Frek. | Sat│ │
│ │ • Activity                    │ │ │ • Biaya Satuan -> Total (Rp)   │ │
│ ├───────────────────────────────┤ │ ├────────────────────────────────┤ │
│ │ Dokumen TOR (9 Seksi)         │ │ │ Ringkasan Pertanggungjawaban   │ │
│ │ 1. Informasi Program          │ │ │ • Akumulasi Kode Budget Tunggal│ │
│ │ 2. Latar Belakang Masalah     │ │ │ • Uang Muka Masuk              │ │
│ │ 3. Tujuan Umum & Khusus       │ │ │ • Realisasi Belanja (Rp)       │ │
│ │ 4. Peserta Kegiatan (Tabel)   │ │ │ • Sisa Uang Muka / Kekurangan  │ │
│ │ 5. Tim Pelaksana & Tugas      │ │ │ • Cetak Pratinjau              │ │
│ │ 6. Rundown Kegiatan           │ │ ├────────────────────────────────┤ │
│ │ 7. Risk & Mitigation          │ │ │ Jejak Audit Terpisah           │ │
│ │ 8. Logistik & Catatan         │ │ │ • Tombol Update Terbaru        │ │
│ │ 9. Monitoring & Evaluation    │ │ │ • Riwayat Perubahan Realisasi  │ │
│ └───────────────────────────────┘ │ │ • Fitur Show / Hide Tabel      │ │
│                                   │ └────────────────────────────────┘ │
├───────────────────────────────────┴────────────────────────────────────┤
│ 3. CORE PLATFORM & STATE                                               │
│ • Role-Based Auth: Staff, PM, Finance, Director                        │
│ • Express Server + In-Memory/JSON Storage + REST APIs                  │
│ • Unified Audit Trail Logger (Global & Module-specific)                │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 4. Draft Master Prompt Siap Pakai untuk AI Studio

Berikut adalah naskah prompt utuh yang diformulasikan untuk diinput ke AI Studio saat ingin membangun ulang sistem ini secara komprehensif:

```markdown
Bertindaklah sebagai Senior Full-Stack Engineer dan UI/UX Designer berpengalaman dalam membangun sistem manajemen program NGO, document management system, dan sistem keuangan kas operasional dengan estetika Notion.

Bangun aplikasi web full-stack terintegrasi: "Sistem Manajemen Program, Dokumen TOR & Cash Advance Keuangan NGO" untuk Yayasan WIJNA (Wahana Wijnamurti Indonesia).

### 1. PRINSIP DESAIN & AESTHETICS (NOTION-INSPIRED)
- Visual Style: Minimalis, modern, editorial, document-centric, dan data-dense tanpa terlihat sesak.
- Color Palette: Latar aplikasi abu-abu hangat (#F5F6F7), kertas dokumen putih bersih (#FFFFFF) dengan border tipis netral (#EDEDEC), teks utama dark charcoal (#292524 / #2F3437), aksen biru kalem (#1E3A8A / #1D4ED8), aksen status hijau (#047857), dan aksen kekurangan/bahaya (#B91C1C).
- Spacing & Rhythm: Padding kontainer 16–24px, gap antar elemen 12–16px. Hindari kartu-kartu besar dengan shadow tebal atau style SaaS generik. Gunakan pemisah garis tipis dan indentasi hierarki.

### 2. STRUKTUR HIERARKI PROGRAM ORGANISASI
Sistem harus memuat hierarki 4-level wajib:
1. PROGRAM: Nama Program Induk, Wilayah Kerja, dan Periode Tahunan.
2. OUTCOME: Capaian jangka menengah / dampak perubahan masyarakat.
3. OUTPUT: Produk/pelatihan spesifik yang dihasilkan.
4. ACTIVITY: Kegiatan teknis lapangan yang menjadi dasar pembuatan Dokumen TOR.

### 3. MODUL KERANGKA ACUAN KERJA (TOR)
Halaman detail dokumen TOR harus menampilkan 9 seksi dokumen terstruktur dengan dukungan accordion ringkas:
1. Compact TOR Header: Label kecil program management, judul kegiatan (21–24px), nomor TOR (contoh: TOR/001/WIJNA/PALKL/1.2.1/X/2026), lokasi dan tanggal pelaksanaan dalam satu baris ringkas, serta status badge pengajuan & indikator tenggat laporan (dihitung dinamis).
2. Hierarki Program: Ditampilkan bersarang (nested) dengan label badge kecil: PROGRAM → OUTCOME → OUTPUT → ACTIVITY.
3. Metadata Pelaksanaan & Tim Penanggung Jawab:
   - PIC Utama: Hanya satu penanggung jawab utama yang ditegaskan (contoh: Budi Santoso).
   - Tim Pelaksana: Daftar tim pendamping (contoh: Siti Rahmawati, Maya Safitri).
   - Pembuat Dokumen: Pembuat beserta peran (contoh: Budi Santoso - Staff).
   - Dilengkapi jadwal pelaksanaan, deadline laporan, dan lokasi.
4. Latar Belakang Masalah: Uraian kendala lapangan dan rasional intervensi.
5. Tujuan: Memisahkan secara tegas Tujuan Umum dan Tujuan Khusus.
6. Target Peserta: Tabel ringkas target peserta (No, Target Peserta, Est. Laki-laki, Est. Perempuan, Keterangan) dengan kalkulasi baris total (Σ) otomatis dan kriteria peserta.
7. Tim Pelaksana & Tanggung Jawab: Tabel peran teknis (Nama-Lembaga, Role/Peran, Responsibility/Tugas) dan catatan briefing tim.
8. Rundown Kegiatan: Jadwal hari per hari, jam, agenda, tempat, dan PIC sesi.
9. Anticipated Field Challenges & Mitigation: Matriks kendala potensial, mitigasi teknis, dan PIC penanggung jawab risiko.
10. Catatan Tambahan, Logistik & MOV: Kebutuhan alat peraga dan rencana monitoring verifikasi bukti.

### 4. WORKFLOW PERSETUJUAN BERJENJANG (APPROVAL WORKFLOW)
- Alur Status: Draft → Diajukan → Menunggu Persetujuan Finance → Menunggu Persetujuan Director → Disetujui (atau Perlu Perbaikan / Ditolak).
- Aturan Otorisasi: Pembuat dokumen tidak boleh menyetujui dokumennya sendiri. Reviewer (Finance/Director) dapat memilih: Setujui, Minta Perbaikan (wajib catatan), atau Tolak.
- Audit Log Persetujuan: Mencatat kronologi waktu, nama aktor, jabatan, aksi, dan komentar peninjau dalam timeline vertikal.

### 5. MODUL CASH ADVANCE (PENGAJUAN UANG MUKA OPERASIONAL)
- Multi-Tahap Cash Advance: Satu kegiatan TOR dapat mengajukan beberapa kasbon secara bertahap (CA #01, CA #02, dst.).
- Penomoran Berjenjang Otomatis: Menggunakan sub-kode pembeda bertahap, misal: CA/001.01/WIJNA/... untuk pengajuan pertama, CA/001.02/WIJNA/... untuk pengajuan kedua.
- Tabel Rincian Anggaran Kasbon:
  - Header Kolom: No | Kode | Deskripsi / Uraian Kebutuhan | VOLUME | SATUAN | FREK. | SATUAN | Biaya Satuan (Rp) | Total (Rp) | Aksi.
  - Dropdown Kode Budget: Bersih hanya menampilkan kode murni (misal: 1.1.2, 1.4.1, 2.1.1) tanpa label kategori yang panjang.
  - Deskripsi Kegiatan: Muncul otomatis dari Master Budget saat kode dipilih, tanpa kotak bertumpuk di dalam sel.
  - Satuan Ganda: Memiliki kolom Satuan Volume (misal: Paket, Orang) dan Satuan Frekuensi (misal: Hari, Kali).
  - Rumus Total Otomatis: Total = Volume × Frekuensi × Biaya Satuan.
  - Baris Total Ringkas: Menampilkan total rupiah yang diajukan beserta konversi teks terbilang otomatis.

### 6. RINGKASAN PERTANGGUNGJAWABAN DANA (ACCUMULATED SUMMARY)
- Konsolidasi Kode Budget Tunggal (No Duplicates): Mengakumulasikan seluruh item pengajuan dari CA 1, CA 2, dst. berdasarkan Kode Budget yang sama ke dalam SATU baris global. Tidak boleh ada kode budget yang berulang.
- Tabel Pertanggungjawaban Akuntansi:
  - Kolom: No | Kode Budget | Jenis Kegiatan (berdasarkan Budget) | Uang Muka Diterima (Rp) | Realisasi Belanja (Rp) | Sisa Uang Muka (Rp) | Kekurangan (Rp) | % Terpakai.
  - Kolom Keterangan dihilangkan agar tabel fokus pada angka akuntansi.
  - Kolom Realisasi Belanja diperpanjang agar input angka leluasa dan nyaman.
  - Perhitungan Otomatis:
    * Sisa Uang Muka = max(0, Uang Muka Diterima - Realisasi Belanja)
    * Kekurangan = max(0, Realisasi Belanja - Uang Muka Diterima)
    * % Terpakai = (Realisasi Belanja / Uang Muka Diterima) × 100%
  - Header Dokumen: Hanya memiliki SATU tombol aksi utama yaitu tombol "Cetak Pratinjau".

### 7. JEJAK AUDIT TERPISAH (DEDICATED CASH ADVANCE AUDIT TRAIL)
- Di bawah tabel ringkasan kasbon, sediakan panel Jejak Audit Terpisah khusus pelaporan keuangan.
- Tombol "Update Terbaru": Setiap kali angka realisasi belanja diperbarui, klik tombol ini untuk menyimpan perubahan dan mencatat riwayat ke audit trail terpisah (merekam timestamp, pengguna, total realisasi, sisa/kurang, persentase terpakai, dan rincian perubahan yang luas).
- Fitur Show / Hide: Tabel jejak audit keuangan dapat ditampilkan atau disembunyikan dengan satu klik.

Pastikan seluruh fitur interaktif berfungsi penuh (state management tersinkronisasi, kalkulasi angka akurat, responsif desktop-ke-mobile, serta mendukung cetak PDF resmi).
```

---

## 5. Langkah Eksekusi Berikutnya

Setelah rencana dan draft Master Prompt PRD ini disetujui:
1. Master Prompt siap disalin oleh pengguna untuk digunakan pada proyek baru atau dokumentasi sistem organisasi.
2. Jika ada penambahan instruksi khusus pada aplikasi saat ini, perubahan dapat diterapkan langsung pada modul terkait.
